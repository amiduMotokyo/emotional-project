"""Compare inner-trained and full-train models under the strict protocol."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_protocol


def load_group(paths, device):
    return [run_protocol.load_model(Path(path), device) for path in paths]


def evaluate(models, valid, weights, bias, temperature, device):
    probabilities, raw_scores = run_protocol.all_outputs(models, valid, device)
    _, predicted, final = run_protocol.decode(
        probabilities, raw_scores, weights, bias, temperature
    )
    return run_protocol.metric_dict(
        valid["cls"].astype(int), valid["score"], predicted, final
    )


def main():
    root = Path(__file__).resolve().parent
    result = json.loads((root / "reports" / "严格协议结果.json").read_text(encoding="utf-8"))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    raw = run_protocol.data_utils.load_aligned(
        Path(r"E:\E题\E题数据\附件2-数据集特征文件\aligned_50.pkl")
    )
    train = run_protocol.data_utils.prepare_split(raw["train"])
    valid = run_protocol.data_utils.prepare_split(raw["valid"])
    scale = run_protocol.data_utils.fit_scale(train)
    run_protocol.data_utils.apply_scale(valid, scale)
    weights = np.asarray(result["ensemble_weights"], dtype=np.float32)
    bias = np.asarray(result["class_bias"], dtype=np.float32)
    temperature = float(result["temperature"])
    inner_models = load_group(
        [item["checkpoint"] for item in result["inner_models"]], device
    )
    final_models = load_group(
        [item["checkpoint"] for item in result["final_models"]], device
    )
    output = {
        "inner_models_on_valid": evaluate(
            inner_models, valid, weights, bias, temperature, device
        ),
        "final_models_on_valid": evaluate(
            final_models, valid, weights, bias, temperature, device
        ),
        "final_models_equal_weight_zero_bias": evaluate(
            final_models,
            valid,
            np.full(len(final_models), 1.0 / len(final_models), dtype=np.float32),
            np.zeros(3, dtype=np.float32),
            1.0,
            device,
        ),
        "weights": weights.tolist(),
        "bias": bias.tolist(),
        "temperature": temperature,
    }
    (root / "reports" / "内层与最终模型对比.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(output, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
