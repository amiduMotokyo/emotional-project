"""Strict protocol: train-only fitting, inner-dev selection, valid once.

No test data is read. The official valid split is not used for early stopping,
model selection, ensemble weights, bias, or temperature.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.optimize import differential_evolution, minimize
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, mean_absolute_error
from sklearn.model_selection import GroupShuffleSplit
from torch import nn
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "problem2_training_v3"))
import data_utils
from train_cross_modal import CrossModalTransformer


MODEL_SPECS = [
    {"kind": "gate", "seed": 4201, "hidden_dim": 96, "missing_probability": 0.8},
    {"kind": "gate", "seed": 4202, "hidden_dim": 96, "missing_probability": 0.7},
    {"kind": "gate", "seed": 4203, "hidden_dim": 128, "missing_probability": 0.8},
    {"kind": "gate", "seed": 4204, "hidden_dim": 128, "missing_probability": 1.0},
    {"kind": "gate", "seed": 4205, "hidden_dim": 160, "missing_probability": 0.8},
    {
        "kind": "cross",
        "seed": 5201,
        "d_model": 128,
        "nhead": 4,
        "layers": 2,
        "dim_feedforward": 256,
        "dropout": 0.1,
        "missing_probability": 0.8,
    },
    {
        "kind": "cross",
        "seed": 5202,
        "d_model": 160,
        "nhead": 5,
        "layers": 2,
        "dim_feedforward": 320,
        "dropout": 0.12,
        "missing_probability": 0.7,
    },
]


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def subset(data: dict, indices: np.ndarray) -> dict:
    result = {}
    for key, value in data.items():
        if isinstance(value, np.ndarray) and value.ndim > 0:
            result[key] = value[indices]
        elif isinstance(value, list):
            result[key] = [value[index] for index in indices]
        else:
            result[key] = value
    return result


def group_id(sample_id: object) -> str:
    text = str(sample_id)
    return text.split("$_$", 1)[0]


def make_model(spec: dict) -> nn.Module:
    if spec["kind"] == "gate":
        return data_utils.MissingAwareFusion(spec["hidden_dim"])
    return CrossModalTransformer(
        d_model=spec["d_model"],
        nhead=spec["nhead"],
        layers=spec["layers"],
        dim_feedforward=spec["dim_feedforward"],
        dropout=spec["dropout"],
    )


def train_model(
    spec: dict,
    train: dict,
    dev: dict,
    output: Path,
    device: torch.device,
    epochs: int,
    patience: int,
    batch_size: int,
    lr: float,
    fixed_epochs: int | None = None,
) -> dict:
    set_seed(spec["seed"])
    model = make_model(spec).to(device)
    train_loader = DataLoader(
        data_utils.AlignmentDataset(train),
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    dev_loader = DataLoader(
        data_utils.AlignmentDataset(dev),
        batch_size=batch_size * 2,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    weights = data_utils.class_weights(train["cls"]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, fixed_epochs or epochs), eta_min=lr * 0.1
    )
    rng = random.Random(spec["seed"])
    best_score = -1e9
    best_epoch = 0
    best_state = None
    history = []
    start = time.time()
    max_epochs = fixed_epochs or epochs

    for epoch in range(1, max_epochs + 1):
        model.train()
        losses = []
        for batch in train_loader:
            text, audio, vision, tmask, amask, vmask, cls, score, _ = batch
            masks = data_utils.training_missing_masks(
                [tmask.to(device), amask.to(device), vmask.to(device)],
                spec["missing_probability"],
                rng,
            )
            optimizer.zero_grad(set_to_none=True)
            logits, raw, _, aux_logits, aux_raw = model(
                text.to(device),
                audio.to(device),
                vision.to(device),
                masks[0],
                masks[1],
                masks[2],
            )
            loss, parts = data_utils.loss_fn(
                logits,
                raw,
                aux_logits,
                aux_raw,
                cls.to(device),
                score.to(device),
                weights,
                masks,
                0.05,
                0.1,
            )
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(parts)
        scheduler.step()
        selection, cases = data_utils.evaluate_selection(model, dev_loader, device)
        record = {
            "epoch": epoch,
            "seconds": time.time() - start,
            "train_loss": float(np.mean([item["loss"] for item in losses])),
            "selection_score": selection["selection_score"],
            "clean_accuracy": selection["clean"]["accuracy"],
            "clean_macro_f1": selection["clean"]["macro_f1"],
            "clean_mae": selection["clean"]["mae"],
            "clean_pearson": selection["clean"]["pearson"],
        }
        history.append(record)
        print(
            "inner",
            spec["kind"],
            spec["seed"],
            "epoch",
            epoch,
            "loss",
            round(record["train_loss"], 4),
            "dev_acc",
            round(record["clean_accuracy"], 4),
            "dev_f1",
            round(record["clean_macro_f1"], 4),
            "select",
            round(record["selection_score"], 4),
            flush=True,
        )
        if fixed_epochs is None and selection["selection_score"] > best_score + 1e-4:
            best_score = selection["selection_score"]
            best_epoch = epoch
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
        if fixed_epochs is None and epoch - best_epoch >= patience:
            break

    if fixed_epochs is None:
        if best_state is None:
            raise RuntimeError("no valid inner checkpoint")
        model.load_state_dict(best_state)
    else:
        best_epoch = fixed_epochs
        best_score = float("nan")
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = {
        "state_dict": model.state_dict(),
        "architecture": "cross_modal_transformer" if spec["kind"] == "cross" else "gate",
        "seed": spec["seed"],
        "best_epoch": best_epoch,
        "best_selection": best_score,
        "model_kwargs": (
            {
                "d_model": spec["d_model"],
                "nhead": spec["nhead"],
                "layers": spec["layers"],
                "dim_feedforward": spec["dim_feedforward"],
                "dropout": spec["dropout"],
            }
            if spec["kind"] == "cross"
            else {}
        ),
        "config": {
            "hidden_dim": spec.get("hidden_dim", spec.get("d_model", 128)),
            "missing_probability": spec["missing_probability"],
        },
    }
    torch.save(checkpoint, output / "best_model.pt")
    with (output / "history.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    return {"checkpoint": checkpoint, "history": history}


def load_model(path: Path, device: torch.device) -> nn.Module:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    if checkpoint["architecture"] == "cross_modal_transformer":
        model = CrossModalTransformer(**checkpoint["model_kwargs"]).to(device)
    else:
        model = data_utils.MissingAwareFusion(
            checkpoint["config"]["hidden_dim"]
        ).to(device)
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model


def model_outputs(
    model: nn.Module,
    data: dict,
    device: torch.device,
    missing_mode: str = "none",
    rate: float = 0.3,
    position: str = "middle",
    seed: int = 8100,
):
    loader = DataLoader(data_utils.AlignmentDataset(data), batch_size=128, shuffle=False)
    rng = random.Random(seed)
    probabilities = []
    raw_scores = []
    for batch in loader:
        text, audio, vision, tmask, amask, vmask, _, _, _ = batch
        masks = [tmask.to(device), amask.to(device), vmask.to(device)]
        if missing_mode != "none":
            masks = data_utils.contiguous_missing_masks(
                masks, missing_mode, rate, position, rng
            )
        with torch.inference_mode():
            logits, raw, _, _, _ = model(
                text.to(device),
                audio.to(device),
                vision.to(device),
                masks[0],
                masks[1],
                masks[2],
            )
        probabilities.append(torch.softmax(logits, dim=1).cpu().numpy())
        raw_scores.append(raw.cpu().numpy())
    return np.concatenate(probabilities), np.concatenate(raw_scores)


def all_outputs(models, data, device, seed=8100, **kwargs):
    probs = []
    raw = []
    for index, model in enumerate(models):
        p, r = model_outputs(
            model,
            data,
            device,
            seed=seed + index * 97,
            **kwargs,
        )
        probs.append(p)
        raw.append(r)
    return np.stack(probs), np.stack(raw)


def unpack(params, n_models):
    weights = np.exp(params[:n_models] - params[:n_models].max())
    weights /= weights.sum()
    bias = np.array([params[n_models], params[n_models + 1], 0.0])
    temperature = np.exp(params[n_models + 2])
    return weights, bias, temperature


def decode(probabilities, raw_scores, weights, bias, temperature):
    probs = np.tensordot(weights, probabilities, axes=(0, 0))
    raw = np.tensordot(weights, raw_scores, axes=(0, 0))
    adjusted = (np.log(np.clip(probs, 1e-9, 1.0)) + bias) / temperature
    adjusted -= adjusted.max(axis=1, keepdims=True)
    adjusted = np.exp(adjusted)
    adjusted /= adjusted.sum(axis=1, keepdims=True)
    predicted = adjusted.argmax(axis=1)
    final = np.where(
        predicted == 1,
        0.0,
        np.where(predicted == 2, np.abs(raw), -np.abs(raw)),
    )
    return adjusted, predicted, final


def metric_dict(labels, scores, predicted, final):
    pearson = (
        float(np.corrcoef(scores, final)[0, 1])
        if np.std(final) > 1e-8
        else 0.0
    )
    return {
        "accuracy": float(accuracy_score(labels, predicted)),
        "macro_f1": float(f1_score(labels, predicted, average="macro", zero_division=0)),
        "mae": float(mean_absolute_error(scores, final)),
        "pearson": pearson,
        "per_class_f1": f1_score(
            labels, predicted, labels=[0, 1, 2], average=None, zero_division=0
        ).tolist(),
        "confusion_matrix": confusion_matrix(labels, predicted, labels=[0, 1, 2]).tolist(),
        "n": len(labels),
    }


def objective(params, probabilities, raw_scores, labels, n_models):
    weights, bias, temperature = unpack(params, n_models)
    _, predicted, final = decode(
        probabilities, raw_scores, weights, bias, temperature
    )
    return (
        -float(accuracy_score(labels, predicted))
        -0.0003 * float(f1_score(labels, predicted, average="macro", zero_division=0))
        +0.00005 * float(mean_absolute_error(labels, final))
    )


def plot_confusion(path: Path, labels, predicted, title: str) -> None:
    matrix = confusion_matrix(labels, predicted, labels=[0, 1, 2])
    fig, axis = plt.subplots(figsize=(6, 5))
    image = axis.imshow(matrix, cmap="Blues")
    fig.colorbar(image, ax=axis)
    axis.set_xticks([0, 1, 2], data_utils.LABELS)
    axis.set_yticks([0, 1, 2], data_utils.LABELS)
    axis.set_xlabel("预测类别")
    axis.set_ylabel("真实类别")
    axis.set_title(title)
    for row in range(3):
        for column in range(3):
            axis.text(
                column,
                row,
                str(matrix[row, column]),
                ha="center",
                va="center",
                color="white" if matrix[row, column] > matrix.max() / 2 else "black",
            )
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_regression(path: Path, scores, final, title: str) -> None:
    fig, axis = plt.subplots(figsize=(6, 5))
    axis.scatter(scores, final, alpha=0.45, s=18)
    lower = min(float(scores.min()), float(final.min()))
    upper = max(float(scores.max()), float(final.max()))
    axis.plot([lower, upper], [lower, upper], color="black", linewidth=1)
    axis.set_xlabel("真实强度")
    axis.set_ylabel("预测强度")
    axis.set_title(title)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path,
                        default=Path(r"E:\E题\E题数据\附件2-数据集特征文件\aligned_50.pkl"))
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    matplotlib.rcParams["axes.unicode_minus"] = False

    raw = data_utils.load_aligned(args.data)
    train_all = data_utils.prepare_split(raw["train"])
    valid = data_utils.prepare_split(raw["valid"])
    scale = data_utils.fit_scale(train_all)
    data_utils.apply_scale(train_all, scale)
    data_utils.apply_scale(valid, scale)
    groups = np.array([group_id(item) for item in train_all["sample_id"]])
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=2026)
    inner_train_index, inner_dev_index = next(
        splitter.split(np.arange(len(groups)), groups=groups)
    )
    inner_train = subset(train_all, inner_train_index)
    inner_dev = subset(train_all, inner_dev_index)

    inner_models = []
    inner_records = []
    for spec in MODEL_SPECS:
        name = f"{spec['kind']}_{spec['seed']}"
        output = args.output / "inner_models" / name
        result = train_model(
            spec,
            inner_train,
            inner_dev,
            output,
            device,
            epochs=24,
            patience=6,
            batch_size=32,
            lr=5e-4,
        )
        inner_models.append(load_model(output / "best_model.pt", device))
        inner_records.append(
            {
                "kind": spec["kind"],
                "seed": spec["seed"],
                "best_epoch": result["checkpoint"]["best_epoch"],
                "best_selection": result["checkpoint"]["best_selection"],
                "checkpoint": str(output / "best_model.pt"),
            }
        )

    inner_probs, inner_raw = all_outputs(inner_models, inner_dev, device)
    labels = inner_dev["cls"].astype(int)
    scores = inner_dev["score"]
    n_models = len(inner_models)
    bounds = [(-3, 3)] * n_models + [(-0.5, 0.5), (-0.5, 0.5), (-0.7, 0.7)]
    result = differential_evolution(
        lambda p: objective(p, inner_probs, inner_raw, labels, n_models),
        bounds=bounds,
        seed=2026,
        maxiter=50,
        popsize=12,
        tol=1e-7,
        polish=False,
        workers=1,
    )
    local = minimize(
        lambda p: objective(p, inner_probs, inner_raw, labels, n_models),
        result.x,
        method="Nelder-Mead",
        options={"maxiter": 2500, "xatol": 1e-8, "fatol": 1e-9},
    )
    best = local.x if local.fun <= result.fun else result.x
    weights, bias, temperature = unpack(best, n_models)

    final_models = []
    final_records = []
    for spec, record in zip(MODEL_SPECS, inner_records):
        name = f"{spec['kind']}_{spec['seed']}"
        output = args.output / "final_models" / name
        result = train_model(
            spec,
            train_all,
            inner_dev,
            output,
            device,
            epochs=record["best_epoch"],
            patience=6,
            batch_size=32,
            lr=5e-4,
            fixed_epochs=record["best_epoch"],
        )
        final_models.append(load_model(output / "best_model.pt", device))
        final_records.append(
            {
                "kind": spec["kind"],
                "seed": spec["seed"],
                "fixed_epochs": record["best_epoch"],
                "checkpoint": str(output / "best_model.pt"),
            }
        )

    valid_loader = DataLoader(
        data_utils.AlignmentDataset(valid), batch_size=128, shuffle=False
    )
    valid_probs, valid_raw = all_outputs(final_models, valid, device)
    valid_calibrated, valid_pred, valid_final = decode(
        valid_probs, valid_raw, weights, bias, temperature
    )
    valid_metrics = metric_dict(
        valid["cls"].astype(int), valid["score"], valid_pred, valid_final
    )

    reports = args.output / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    figures = args.output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    summary = {
        "protocol": "train-only fitting; inner-dev selection; valid evaluated once; test not read",
        "inner_split": {
            "train_samples": len(inner_train["cls"]),
            "inner_dev_samples": len(inner_dev["cls"]),
            "train_video_groups": len(set(groups[inner_train_index])),
            "inner_dev_video_groups": len(set(groups[inner_dev_index])),
        },
        "inner_models": inner_records,
        "final_models": final_records,
        "ensemble_weights": weights.tolist(),
        "class_bias": bias.tolist(),
        "temperature": float(temperature),
        "valid_once": valid_metrics,
    }
    (reports / "严格协议结果.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    rows = []
    for index in range(len(valid["cls"])):
        rows.append(
            {
                "sample_id": valid["sample_id"][index],
                "true_polarity": data_utils.LABELS[int(valid["cls"][index])],
                "predicted_polarity": data_utils.LABELS[int(valid_pred[index])],
                "true_intensity": float(valid["score"][index]),
                "predicted_intensity": float(valid_final[index]),
                "prob_negative": float(valid_calibrated[index, 0]),
                "prob_neutral": float(valid_calibrated[index, 1]),
                "prob_positive": float(valid_calibrated[index, 2]),
            }
        )
    with (reports / "严格协议验证集预测.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    plot_confusion(
        figures / "严格协议验证集混淆矩阵.png",
        valid["cls"].astype(int),
        valid_pred,
        "严格协议：验证集混淆矩阵",
    )
    plot_regression(
        figures / "严格协议验证集强度回归.png",
        valid["score"],
        valid_final,
        "严格协议：验证集情感强度",
    )
    fig, axis = plt.subplots(figsize=(11, 4.8))
    names = [f"{item['kind']}-{item['seed']}" for item in final_records]
    axis.bar(range(len(weights)), weights, color=["#4472C4"] * 5 + ["#ED7D31"] * 2)
    axis.set_xticks(range(len(weights)), names, rotation=35, ha="right")
    axis.set_ylabel("inner-dev优化权重")
    axis.set_title("严格协议：模型集成权重")
    fig.tight_layout()
    fig.savefig(figures / "严格协议集成权重.png", dpi=180)
    plt.close(fig)
    print(json.dumps({"valid_once": valid_metrics}, ensure_ascii=False, indent=2), flush=True)
    print("output", args.output, flush=True)


if __name__ == "__main__":
    main()
