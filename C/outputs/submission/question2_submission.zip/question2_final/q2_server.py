"""Question 2: robust multimodal prediction on aligned MOSEI features.

Runs on the supplied train/valid split. Attachment 3 is used only for final
inference. The text encoder is a frozen local MiniLM checkpoint and is never
fine-tuned on outside sentiment data.
"""

from __future__ import annotations

import argparse
import csv
import gc
import json
import pickle
import random
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, mean_absolute_error
from torch import nn
from torch.utils.data import DataLoader, Dataset


LABELS = ['Negative', 'Neutral', 'Positive']
SEED = 20260924


def seed_all(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def encoded_text(model, bert: np.ndarray, device: str, batch: int = 64) -> np.ndarray:
    ids = np.rint(bert[:, 0]).astype(np.int64)
    attention = np.rint(bert[:, 1]).astype(np.int64)
    values = []
    if hasattr(model, 'run'):
        for start in range(0, len(ids), batch):
            x = ids[start:start+batch]
            a = attention[start:start+batch]
            y = model.run(None, {'input_ids':x,'attention_mask':a,
                                 'token_type_ids':np.zeros_like(x)})[0]
            values.append(y.astype(np.float16))
    else:
        model.eval()
        with torch.inference_mode():
            for start in range(0, len(ids), batch):
                x = torch.from_numpy(ids[start:start+batch]).to(device)
                a = torch.from_numpy(attention[start:start+batch]).to(device)
                y = model(input_ids=x, attention_mask=a).last_hidden_state
                values.append(y.float().cpu().numpy().astype(np.float16))
    return np.concatenate(values)


def assemble(bert: np.ndarray, text: np.ndarray, audio: np.ndarray,
             vision: np.ndarray, cls=None, score=None) -> dict:
    token_ids = np.rint(bert[:, 0]).astype(np.int32)
    attention = bert[:, 1] > 0
    tmask = attention & (token_ids != 101) & (token_ids != 102) & (token_ids != 100)
    a = np.nan_to_num(audio.astype(np.float32))
    v = np.nan_to_num(vision.astype(np.float32))
    amask = attention & np.any(a != 0, axis=-1)
    vmask = attention & np.any(v != 0, axis=-1)
    result = dict(text=text, audio=a, vision=v, tmask=tmask, amask=amask,
                  vmask=vmask, token_ids=token_ids, attention=attention)
    if cls is not None:
        result['cls'] = np.asarray(cls, np.int64)
        result['score'] = np.asarray(score, np.float32)
    return result


def prepare(args):
    args.cache.mkdir(parents=True, exist_ok=True)
    print('Loading aligned training file', flush=True)
    with (args.data_root/'附件2-数据集特征文件/aligned_50.pkl').open('rb') as f:
        data = pickle.load(f)
    if args.onnx_model:
        import onnxruntime as ort
        model = ort.InferenceSession(str(args.onnx_model), providers=['CPUExecutionProvider'])
    else:
        from transformers import AutoModel
        model = AutoModel.from_pretrained(str(args.text_model), local_files_only=True).to(args.device)
    for name in ('train', 'valid'):
        split = data[name]
        print('Encoding', name, len(split['id']), flush=True)
        text = encoded_text(model, split['text_bert'], args.device)
        result = assemble(split['text_bert'], text, split['audio'], split['vision'],
                          split['classification_labels'], split['regression_labels'])
        np.savez_compressed(args.cache/f'{name}.npz', **result)
    del data
    gc.collect()
    q2 = args.data_root/'附件3-模态缺失特征样本/对齐版本'
    for path in sorted(q2.glob('*.pkl')):
        with path.open('rb') as f:
            item = pickle.load(f)['test']
        text = encoded_text(model, item['text_bert'], args.device)
        result = assemble(item['text_bert'], text, item['audio'], item['vision'])
        np.savez_compressed(args.cache/f'q2_{path.stem}.npz', **result)
    print('Prepared 30 attachment-3 samples', flush=True)


def load_npz(path: Path) -> dict:
    with np.load(path) as d:
        return {k: d[k] for k in d.files}


def fit_av_scale(train: dict) -> dict:
    scale = {}
    for field, mask in [('audio', 'amask'), ('vision', 'vmask')]:
        values = train[field][train[mask]]
        mean = values.mean(axis=0).astype(np.float32)
        std = np.maximum(values.std(axis=0).astype(np.float32), 1e-4)
        scale[field] = (mean, std)
    return scale


def apply_scale(data: dict, scale: dict):
    for field, mask in [('audio', 'amask'), ('vision', 'vmask')]:
        mean, std = scale[field]
        value = np.clip((data[field] - mean) / std, -5, 5)
        data[field] = np.where(data[mask][..., None], value, 0).astype(np.float32)


class MultiData(Dataset):
    def __init__(self, data: dict):
        self.data = data
    def __len__(self):
        return len(self.data['text'])
    def __getitem__(self, i):
        d = self.data
        return tuple(torch.from_numpy(d[k][i].copy()) for k in ('text','audio','vision','tmask','amask','vmask')) + \
               (torch.tensor(int(d['cls'][i])), torch.tensor(float(d['score'][i]), dtype=torch.float32))


class Pool(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.score = nn.Linear(dim, 1)
    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        logits = self.score(x).squeeze(-1).masked_fill(~mask, -1e4)
        weights = torch.softmax(logits, dim=1) * mask.float()
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        return (x * weights.unsqueeze(-1)).sum(dim=1)


class Fusion(nn.Module):
    def __init__(self, dim: int = 64):
        super().__init__()
        self.tproj = nn.Sequential(nn.Linear(384, dim), nn.LayerNorm(dim), nn.GELU())
        self.aproj = nn.Sequential(nn.Linear(74, dim), nn.LayerNorm(dim), nn.GELU())
        self.vproj = nn.Sequential(nn.Linear(35, dim), nn.LayerNorm(dim), nn.GELU())
        self.pools = nn.ModuleList([Pool(dim) for _ in range(3)])
        self.gate = nn.Linear(dim*3+3, 3)
        self.head = nn.Sequential(nn.Linear(dim*4+3, 128), nn.LayerNorm(128), nn.GELU(),
                                  nn.Dropout(0.25), nn.Linear(128, 64), nn.GELU(), nn.Linear(64, 4))
    def forward(self, text, audio, vision, tmask, amask, vmask):
        masks = [tmask.bool(), amask.bool(), vmask.bool()]
        inputs = [text.float(), audio.float(), vision.float()]
        projections = [self.tproj, self.aproj, self.vproj]
        pooled = []
        for i in range(3):
            x = projections[i](inputs[i])
            pooled.append(self.pools[i](x, masks[i]))
        rates = torch.stack([m.float().mean(dim=1) for m in masks], dim=1)
        joined = torch.cat([*pooled, rates], dim=1)
        present = torch.stack([m.any(dim=1) for m in masks], dim=1)
        gate_logits = self.gate(joined).masked_fill(~present, -1e4)
        gate = torch.softmax(gate_logits, dim=1) * present.float()
        gate = gate / gate.sum(dim=1, keepdim=True).clamp_min(1e-8)
        fused = sum(gate[:,i:i+1] * pooled[i] for i in range(3))
        out = self.head(torch.cat([*pooled, fused, rates], dim=1))
        return out[:, :3], 3*torch.tanh(out[:, 3]), gate


def corrupted_masks(masks: list[torch.Tensor], mode: str, rate: float = 0.3,
                    position: str = 'random') -> list[torch.Tensor]:
    result = [m.clone() for m in masks]
    n, length = masks[0].shape
    if mode == 'none':
        return result
    for i in range(n):
        valid = int((masks[0][i] | masks[1][i] | masks[2][i]).sum().item())
        if valid < 2:
            continue
        width = max(1, round(rate * valid))
        if position == 'start':
            start = 1
        elif position == 'middle':
            start = max(1, (valid - width)//2)
        elif position == 'end':
            start = max(1, valid - width)
        else:
            start = random.randint(1, max(1, valid-width))
        start = min(start, length-1)
        end = min(length, start+width)
        if mode == 'random':
            count = random.choice([1,1,1,2,2,3])
            choices = random.sample(range(3), count)
        else:
            choices = [{'text':0,'audio':1,'vision':2}[mode]]
        for j in choices:
            result[j][i,start:end] = False
    return result


def batch_to_device(batch, device: str):
    return [x.to(device, non_blocking=True) for x in batch]


@torch.inference_mode()
def evaluate(model: Fusion, loader: DataLoader, device: str, mode='none', rate=0.3,
             position='middle', seed=SEED) -> dict:
    model.eval()
    previous_random_state = random.getstate()
    random.seed(seed)
    classes, truth, scores, estimates, probabilities = [], [], [], [], []
    for batch in loader:
        t,a,v,tm,am,vm,c,y = batch_to_device(batch,device)
        masks = corrupted_masks([tm,am,vm],mode,rate,position)
        logits,pred,_ = model(t,a,v,*masks)
        prob = torch.softmax(logits,dim=1)
        classes.append(c.cpu().numpy()); truth.append(y.cpu().numpy())
        scores.append(prob.argmax(1).cpu().numpy())
        estimates.append(pred.cpu().numpy()); probabilities.append(prob.cpu().numpy())
    c=np.concatenate(classes); y=np.concatenate(truth); p=np.concatenate(scores)
    z=np.concatenate(estimates); prob=np.concatenate(probabilities)
    random.setstate(previous_random_state)
    pearson=float(np.corrcoef(y,z)[0,1]) if np.std(z)>1e-8 else 0.0
    return {'accuracy':float(accuracy_score(c,p)), 'macro_f1':float(f1_score(c,p,average='macro',zero_division=0)),
            'mae':float(mean_absolute_error(y,z)), 'pearson':pearson,
            'per_class_f1':f1_score(c,p,average=None,labels=[0,1,2],zero_division=0).tolist(),
            'n':len(c)}


def criterion(logits, pred, cls, y, weights):
    return nn.functional.cross_entropy(logits,cls,weight=weights)+0.8*nn.functional.smooth_l1_loss(pred,y)


def train_one(model: Fusion, train_loader: DataLoader, valid_loader: DataLoader,
              device: str, robust: bool, seed: int, checkpoint: Path, epochs=35,
              lr: float = 8e-4):
    seed_all(seed)
    model.to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=0.01)
    counts=np.bincount(train_loader.dataset.data['cls'],minlength=3)
    weights=torch.tensor(np.sqrt(counts.sum()/(3*np.maximum(counts,1))),dtype=torch.float32,device=device)
    best=-1e9; best_epoch=0; history=[]
    for epoch in range(1,epochs+1):
        model.train()
        losses=[]
        for batch in train_loader:
            t,a,v,tm,am,vm,c,y=batch_to_device(batch,device)
            if robust and random.random()<0.8:
                masks=corrupted_masks([tm,am,vm],'random',random.choice([0.1,0.2,0.3,0.5]),'random')
            else:
                masks=[tm,am,vm]
            optimizer.zero_grad(set_to_none=True)
            logits,pred,_=model(t,a,v,*masks)
            loss=criterion(logits,pred,c,y,weights)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        clean=evaluate(model,valid_loader,device)
        if robust:
            damaged=[evaluate(model,valid_loader,device,m,0.3,'middle') for m in ('text','audio','vision')]
            f1=(clean['macro_f1']+sum(z['macro_f1'] for z in damaged))/4
            mae=(clean['mae']+sum(z['mae'] for z in damaged))/4
            pearson=(clean['pearson']+sum(z['pearson'] for z in damaged))/4
        else:
            f1,mae,pearson=clean['macro_f1'],clean['mae'],clean['pearson']
        value=f1-0.15*mae+0.05*pearson
        record={'epoch':epoch,'train_loss':float(np.mean(losses)),'clean':clean,'selection_score':value}
        history.append(record)
        print('robust' if robust else 'baseline',seed,epoch,'loss',round(record['train_loss'],3),
              'f1',round(clean['macro_f1'],3),'mae',round(clean['mae'],3),'select',round(value,3),flush=True)
        if value>best+1e-4:
            best=value;best_epoch=epoch
            torch.save({'state_dict':model.state_dict(),'seed':seed,'robust':robust,'epoch':epoch},checkpoint)
        if epoch-best_epoch>=7:
            break
    model.load_state_dict(torch.load(checkpoint,map_location=device,weights_only=False)['state_dict'])
    return {'best_epoch':best_epoch,'best_score':best,'history':history}


def predict_q2(model: Fusion, data: dict, device: str):
    model.eval()
    with torch.inference_mode():
        args=[torch.from_numpy(data[k].copy()).to(device) for k in ('text','audio','vision','tmask','amask','vmask')]
        logits,score,gate=model(*args)
        return torch.softmax(logits,1).cpu().numpy()[0],float(score.cpu().numpy()[0]),gate.cpu().numpy()[0]


def run(args):
    args.output.mkdir(parents=True,exist_ok=True)
    train=load_npz(args.cache/'train.npz'); valid=load_npz(args.cache/'valid.npz')
    scale=fit_av_scale(train)
    for d in (train,valid): apply_scale(d,scale)
    np.savez_compressed(args.output/'audio_vision_normalization.npz',
                        audio_mean=scale['audio'][0],audio_std=scale['audio'][1],
                        vision_mean=scale['vision'][0],vision_std=scale['vision'][1])
    train_loader=DataLoader(MultiData(train),batch_size=64,shuffle=True,num_workers=0,pin_memory=True)
    valid_loader=DataLoader(MultiData(valid),batch_size=128,shuffle=False,num_workers=0,pin_memory=True)
    baseline=Fusion()
    base_history=train_one(baseline,train_loader,valid_loader,args.device,False,SEED,
                           args.output/'baseline.pt')
    robust=Fusion()
    robust_history=train_one(robust,train_loader,valid_loader,args.device,True,SEED+1,
                             args.output/'robust.pt')
    report={'data_version':'aligned_50.pkl','split_sizes':{'train':len(train['cls']),'valid':len(valid['cls'])},
            'class_mapping':dict(enumerate(LABELS)),
            'text_encoder':str(args.onnx_model or args.text_model),
            'selection':'validation macro-F1 - 0.15 MAE + 0.05 Pearson; robust averages clean and 30% missing',
            'baseline_training':base_history,'robust_training':robust_history,
            'clean':{},'missing_grid':[]}
    report['clean']['baseline']=evaluate(baseline,valid_loader,args.device)
    report['clean']['robust']=evaluate(robust,valid_loader,args.device)
    for modality in ('text','audio','vision'):
        for rate in (0.1,0.3,0.5):
            for position in ('start','middle','end'):
                met=evaluate(robust,valid_loader,args.device,modality,rate,position)
                report['missing_grid'].append({'modality':modality,'rate':rate,'position':position,**met})
    for modality in ('text','audio','vision'):
        report.setdefault('baseline_30pct',{})[modality]=evaluate(baseline,valid_loader,args.device,modality,0.3,'middle')
    rows=[]
    for path in sorted(args.cache.glob('q2_*.npz')):
        item=load_npz(path)
        apply_scale(item,scale)
        p,y,gate=predict_q2(robust,item,args.device)
        rows.append({'sample_id':path.stem.removeprefix('q2_'),'polarity':LABELS[int(p.argmax())],
                     'intensity':round(y,6),'prob_negative':round(float(p[0]),6),
                     'prob_neutral':round(float(p[1]),6),'prob_positive':round(float(p[2]),6),
                     'text_observed_ratio':round(float(item['tmask'].mean()),4),
                     'audio_observed_ratio':round(float(item['amask'].mean()),4),
                     'vision_observed_ratio':round(float(item['vmask'].mean()),4),
                     'gate_text':round(float(gate[0]),4),'gate_audio':round(float(gate[1]),4),
                     'gate_vision':round(float(gate[2]),4)})
    with (args.output/'attachment3_predictions.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    with (args.output/'validation_report.json').open('w',encoding='utf8') as f:
        json.dump(report,f,ensure_ascii=False,indent=2)
    print('RESULT',json.dumps(report['clean'],ensure_ascii=False),flush=True)
    print('Wrote',len(rows),'attachment-3 predictions',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--text-model',type=Path,required=True)
    p.add_argument('--onnx-model',type=Path)
    p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu')
    p.add_argument('--prepare',action='store_true')
    a=p.parse_args()
    seed_all(SEED)
    if a.prepare:
        prepare(a)
    else:
        run(a)
