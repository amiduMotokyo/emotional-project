"""Inference-only entry point for the compact Question 2 submission package."""

from __future__ import annotations

import argparse
import csv
import pickle
from pathlib import Path

import numpy as np
import onnxruntime as ort
import torch

from q2_server import LABELS, Fusion, apply_scale, assemble, predict_q2


def infer(data_root: Path, package: Path, output: Path, device: str):
    session=ort.InferenceSession(str(package/'text_encoder_int8.onnx'),
                                 providers=['CPUExecutionProvider'])
    z=np.load(package/'audio_vision_normalization.npz')
    scale={'audio':(z['audio_mean'],z['audio_std']),
           'vision':(z['vision_mean'],z['vision_std'])}
    model=Fusion().to(device)
    checkpoint=torch.load(package/'robust.pt',map_location=device,weights_only=False)
    model.load_state_dict(checkpoint['state_dict'])
    model.eval()
    q2_dir=data_root/'附件3-模态缺失特征样本/对齐版本'
    rows=[]
    for path in sorted(q2_dir.glob('*.pkl')):
        with path.open('rb') as f:
            source=pickle.load(f)['test']
        bert=source['text_bert']
        ids=np.rint(bert[:,0]).astype(np.int64)
        attention=np.rint(bert[:,1]).astype(np.int64)
        text=session.run(None,{'input_ids':ids,'attention_mask':attention,
                               'token_type_ids':np.zeros_like(ids)})[0].astype(np.float16)
        data=assemble(bert,text,source['audio'],source['vision'])
        apply_scale(data,scale)
        p,y,gate=predict_q2(model,data,device)
        rows.append({'sample_id':path.stem,'polarity':LABELS[int(p.argmax())],
                     'intensity':round(y,6),
                     'prob_negative':round(float(p[0]),6),
                     'prob_neutral':round(float(p[1]),6),
                     'prob_positive':round(float(p[2]),6),
                     'text_observed_fraction_of_50':round(float(data['tmask'].mean()),4),
                     'audio_observed_fraction_of_50':round(float(data['amask'].mean()),4),
                     'vision_observed_fraction_of_50':round(float(data['vmask'].mean()),4),
                     'gate_text':round(float(gate[0]),4),
                     'gate_audio':round(float(gate[1]),4),
                     'gate_vision':round(float(gate[2]),4)})
    if len(rows)!=30 or len({r['sample_id'] for r in rows})!=30:
        raise ValueError(f'expected 30 unique attachment-3 samples, got {len(rows)}')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
    print('Wrote',len(rows),'predictions to',output)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--package',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu')
    a=parser.parse_args();infer(a.data_root,a.package,a.output,a.device)
