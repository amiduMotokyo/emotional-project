# 第二题结果包

本目录包含第二题的最终推理模型、附件3预测、验证结果、分析图和代码。最终推理模型由动态量化 MiniLM ONNX 编码器和鲁棒多模态融合网络组成；预测强度范围为 `[-3, 3]`，极性类别为 Negative、Neutral、Positive。

## 文件

- `attachment3_predictions.csv`：附件3共30条样本的最终预测。
- `robust.pt`：经验证集选择的融合网络权重。
- `text_encoder_int8.onnx`：冻结的 all-MiniLM-L6-v2 动态 int8 文本编码器，约22MB。
- `audio_vision_normalization.npz`：训练集上拟合的音频、视觉标准化参数。
- `q2_infer.py`：最终模型的附件3推理入口。
- `q2_server.py`：特征缓存、模型训练和评测代码。
- `q2_analyze.py`：验证预测、错误分析和图表生成代码。
- `validation_report.json`、`validation_predictions.csv`、`error_analysis.json`：验证集结果和逐条分析。
- `fig_*.png`：混淆矩阵、强度预测和缺失率敏感性图。
- `第二题建模与实验报告.md`：可并入竞赛论文的中文建模和结果说明。

## 运行附件3推理

环境依赖：Python 3.10 或更新版本、PyTorch、NumPy、onnxruntime。使用 CPU 即可运行；融合网络也可指定 CUDA。将赛题数据解压到同一数据根目录，保留 `附件3-模态局部缺失专项测试集/对齐版本/` 文件夹，然后运行：

```bash
python q2_infer.py \
  --data-root /path/to/E题数据 \
  --package /path/to/question2_final \
  --output /path/to/attachment3_predictions.csv \
  --device cpu
```

程序会检查附件3是否得到30个唯一样本，并写出极性、强度、类别概率、模态有效比例和门控权重。

## 重跑训练与验证

训练数据目录需包含附件2、附件3。先用本机已下载的完整 MiniLM 检查点生成缓存，再训练基线和鲁棒模型、评估验证集并推理附件3：

```bash
python q2_server.py \
  --data-root /path/to/E题数据 \
  --text-model /path/to/all-MiniLM-L6-v2 \
  --cache /path/to/cache \
  --output /path/to/training_output \
  --device cuda --prepare

python q2_server.py \
  --data-root /path/to/E题数据 \
  --text-model /path/to/all-MiniLM-L6-v2 \
  --cache /path/to/cache \
  --output /path/to/training_output \
  --device cuda
```

如只运行最终推理，无需下载完整 MiniLM；目录中的 int8 ONNX 模型已包含推理需要的文本编码器。

## 数据和模型约定

训练与验证使用附件2 `aligned_50.pkl` 的 train/valid 划分；附件3仅用于最后推理。训练时文本输入由冻结的 `sentence-transformers/all-MiniLM-L6-v2` 编码。最终小体积推理包将同一编码器替换为动态 int8 ONNX 版本。我们比较过直接量化特征训练和低学习率适配；验证集鲁棒综合分数均低于保留的融合权重，因此最终采用验证表现更好的融合权重。报告中的最终精度数字均由本目录的 int8 ONNX 推理流程在验证集上重新测得。
