"""Validation error analysis and figures for q2_server.py outputs."""

from __future__ import annotations

import argparse
import csv
import json
import pickle
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import confusion_matrix
from torch.utils.data import DataLoader

from q2_server import Fusion, MultiData, apply_scale, load_npz


LABELS = ['Negative', 'Neutral', 'Positive']


def run(data_root: Path, cache: Path, output: Path, device: str):
    report=json.loads((output/'validation_report.json').read_text(encoding='utf8'))
    valid=load_npz(cache/'valid.npz')
    with np.load(output/'audio_vision_normalization.npz') as z:
        scale={'audio':(z['audio_mean'],z['audio_std']), 'vision':(z['vision_mean'],z['vision_std'])}
    apply_scale(valid,scale)
    loader=DataLoader(MultiData(valid),batch_size=128,shuffle=False)
    model=Fusion().to(device)
    checkpoint=torch.load(output/'robust.pt',map_location=device,weights_only=False)
    model.load_state_dict(checkpoint['state_dict'])
    model.eval()
    probs=[]; estimates=[]; gates=[]
    with torch.inference_mode():
        for batch in loader:
            t,a,v,tm,am,vm,_,_=[x.to(device) for x in batch]
            logits,score,gate=model(t,a,v,tm,am,vm)
            probs.append(torch.softmax(logits,1).cpu().numpy())
            estimates.append(score.cpu().numpy())
            gates.append(gate.cpu().numpy())
    probs=np.concatenate(probs); estimates=np.concatenate(estimates); gates=np.concatenate(gates)
    true_cls=valid['cls']; true_score=valid['score']; pred_cls=probs.argmax(1)
    with (data_root/'附件2-数据集特征文件/aligned_50.pkl').open('rb') as f:
        source=pickle.load(f)['valid']
    ids=source['id']; texts=source['raw_text']
    rows=[]
    for i in range(len(true_cls)):
        rows.append({'sample_id':ids[i], 'true_polarity':LABELS[int(true_cls[i])],
                     'predicted_polarity':LABELS[int(pred_cls[i])],
                     'true_intensity':round(float(true_score[i]),6),
                     'predicted_intensity':round(float(estimates[i]),6),
                     'absolute_error':round(float(abs(true_score[i]-estimates[i])),6),
                     'correct_polarity':int(true_cls[i]==pred_cls[i]),
                     'valid_tokens':int(valid['attention'][i].sum()),
                     'observed_text':int(valid['tmask'][i].sum()),
                     'observed_audio':int(valid['amask'][i].sum()),
                     'observed_vision':int(valid['vmask'][i].sum()),
                     'gate_text':round(float(gates[i,0]),5),
                     'gate_audio':round(float(gates[i,1]),5),
                     'gate_vision':round(float(gates[i,2]),5),
                     'raw_text':str(texts[i])})
    with (output/'validation_predictions.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    matrix=confusion_matrix(true_cls,pred_cls,labels=[0,1,2])
    class_errors={LABELS[k]:{'n':int((true_cls==k).sum()),
                             'mae':float(np.abs(true_score[true_cls==k]-estimates[true_cls==k]).mean()),
                             'accuracy':float(np.mean(pred_cls[true_cls==k]==k))} for k in range(3)}
    length=valid['attention'].sum(axis=1)
    buckets={}
    for name,mask in [('short_1_16',length<=16),('medium_17_32',(length>16)&(length<=32)),('long_33_50',length>32)]:
        buckets[name]={'n':int(mask.sum()),'mae':float(np.abs(true_score[mask]-estimates[mask]).mean()),
                       'accuracy':float(np.mean(pred_cls[mask]==true_cls[mask]))}
    summary={'confusion_matrix_rows_true_cols_predicted':matrix.tolist(),
             'class_errors':class_errors,'length_buckets':buckets,
             'mean_gate':dict(zip(('text','audio','vision'),gates.mean(axis=0).astype(float).tolist())),
             'median_absolute_error':float(np.median(np.abs(true_score-estimates)))}
    (output/'error_analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')

    plt.rcParams.update({'figure.dpi':150,'savefig.dpi':220,'font.size':10})
    fig,ax=plt.subplots(figsize=(5,4))
    im=ax.imshow(matrix,cmap='Blues')
    ax.set_xticks(range(3),LABELS,rotation=20);ax.set_yticks(range(3),LABELS)
    ax.set_xlabel('Predicted');ax.set_ylabel('True');ax.set_title('Validation confusion matrix')
    for i in range(3):
        for j in range(3):
            ax.text(j,i,str(matrix[i,j]),ha='center',va='center',color='white' if matrix[i,j]>matrix.max()/2 else 'black')
    fig.colorbar(im,ax=ax,shrink=0.8);fig.tight_layout();fig.savefig(output/'fig_confusion.png');plt.close(fig)

    fig,ax=plt.subplots(figsize=(5,4))
    ax.scatter(true_score,estimates,s=10,alpha=0.4,color='#3269a8')
    ax.plot([-3,3],[-3,3],color='#c44949',linewidth=1)
    ax.set(xlim=(-3.1,3.1),ylim=(-3.1,3.1),xlabel='True intensity',ylabel='Predicted intensity',
           title='Validation intensity predictions')
    ax.grid(alpha=0.2);fig.tight_layout();fig.savefig(output/'fig_regression.png');plt.close(fig)

    for metric,filename,ylabel in [('macro_f1','fig_missing_f1.png','Macro-F1'),('mae','fig_missing_mae.png','MAE')]:
        fig,ax=plt.subplots(figsize=(6,4))
        for modality,color in [('text','#1c6eae'),('audio','#db7533'),('vision','#5c9952')]:
            rates=[];values=[]
            for rate in (0.1,0.3,0.5):
                cells=[x[metric] for x in report['missing_grid'] if x['modality']==modality and x['rate']==rate]
                rates.append(rate);values.append(np.mean(cells))
            ax.plot(rates,values,marker='o',linewidth=2,label=modality,color=color)
        ax.set(xlabel='Masked fraction of valid sequence',ylabel=ylabel,
               title=f'Validation {ylabel} under contiguous masking')
        ax.set_xticks([0.1,0.3,0.5]);ax.grid(alpha=0.2);ax.legend()
        fig.tight_layout();fig.savefig(output/filename);plt.close(fig)
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--cache',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu')
    a=parser.parse_args();run(a.data_root,a.cache,a.output,a.device)
